<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="container py-5 h-100">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-12">
                <div class="card card-registration card-registration-2" style="border-radius: 15px;">
                    <div class="card-body p-0">
                        <form action="/updatedata/<?php echo e($data->id); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                                <div class="row g-0">
                                    <div class="col-lg-6">
                                        <div class="p-5">
                                            <h3 class="fw-normal mb-4" style="color: #4835d4;">Students Infomation</h3>

                                            <div class="mb-3">
                                                <div class="form-outline">
                                                    <label class="form-label" for="formname">Full Name</label>
                                                    <input type="text" name="nama" id="formname" class="form-control" value="<?php echo e($data->nama); ?>"/>
                                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger mt-1" style="color: red;"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <div class="form-outline">
                                                    <label class="form-label" for="formnisn">NISN</label>
                                                    <input type="number" name="nisn" id="formnisn" class="form-control" value="<?php echo e($data->nisn); ?>"/>
                                                    <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger mt-1" style="color: red;"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 mb-3">

                                                    <div class="form-outline">
                                                        <label class="form-label" for="formplace">Place of Birth</label>
                                                        <input type="text" name="tempat" id="formplace" class="form-control" value="<?php echo e($data->tempat); ?>"/>
                                                        <?php $__errorArgs = ['place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger mt-1" style="color: red;"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <div class="form-outline">
                                                        <label class="form-label" for="formttl">Date of Birth</label>
                                                        <input type="date" id="formttl" class="form-control" value="<?php echo e($data->ttl); ?>"/>
                                                        <?php $__errorArgs = ['ttl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger mt-1" style="color: red;"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <div class="form-outline">
                                                    <label class="form-label" for="formjk">Gender</label>
                                                    <select class="form-control form-control" id="defaultSelect" name="jk" aria-label="Default select example">
                                                        <option selected><?php echo e($data->jk); ?></option>
                                                        <option value="1" <?php echo e($data->jk == 1 ? 'selected' : ''); ?>>Male</option>
                                                        <option value="2" <?php echo e($data->jk == 2 ? 'selected' : ''); ?>>Female</option>

                                                    </select>
                                                    <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger mt-1" style="color: red;"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <div class="form-outline">
                                                    <label class="form-label" for="formtelp_students">Phone Number</label>
                                                <input type="number" name="telp_students" id="formtelp_students" class="form-control" value="<?php echo e($data->telp_students); ?>"/>
                                                <?php $__errorArgs = ['telp_students'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger mt-1" style="color: red;"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <div class="form-outline form-white">
                                                    <label class="form-label" for="form">Address</label>
                                                    <textarea class="form-control" id="exampleFormControlTextarea1" name="alamat" rows="3"> <?php echo e($data->alamat); ?></textarea>
                                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger mt-1" style="color: red;"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 bg-primary ">
                                        <div class="p-5">
                                            <h3 class="fw-normal mb-4 text-white">Contact Details</h3>

                                            <div class="mb-3">
                                                <div class="form-outline">
                                                    <label class="form-label text-white" for="form3Examplev4">Major</label>
                                                    <select class="form-control form-control" id="defaultSelect" name="jurusan" aria-label="Default select example">
                                                        <option selected><?php echo e($data->jurusan); ?></option>
                                                        <option value="1">IPA</option>
                                                        <option value="2">IPS</option>
                                                        <option value="2">TAHFIDZ</option>
                                                    </select>
                                                    <?php $__errorArgs = ['jk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger mt-1" style="color: red;"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <div class="form-outline">
                                                    <label class="form-label text-white" for="form3Examplev3">Date of Test</label>
                                                    <input type="date" id="form3Examplev3" name="tanggal_test" class="form-control" value="<?php echo e($data->tanggal_test); ?>"/>
                                                    <?php $__errorArgs = ['tanggal_test'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger mt-1" style="color: red;"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                            <div class="px-5">
                                                <button type="submit" class="btn btn-primary btn-lg bg-light text-primary">Registration</button>
                                            </div>
                                    </div>
                                </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/tugasakhir/resources/views/tampildata.blade.php ENDPATH**/ ?>